﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_App
{
    public partial class Form1 : Form
    {
        TextBox activeTextBox;
        double num1, num2, result;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            activeTextBox = textBox1;
            textBox1.Focus();

        }
        private void textBox1_Click(object sender, EventArgs e)
        {
            activeTextBox = textBox1;
        }

        

        private void textBox2_Click(object sender, EventArgs e)
        {
            activeTextBox = textBox2;
        }


        //All Numbers Button
        private void btn6_Click(object sender, EventArgs e)
        {


            Button btn = (Button)sender;
            if (activeTextBox != null)
            {
                activeTextBox.Text += btn.Text;
            }
            if (textBox1.Focused)
            {
                textBox1.Text += btn.Text;
            }
            else if (textBox2.Focused)
            {
                textBox2.Text += btn.Text;
            }


        }


        //Add button
        private void btnplus_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(textBox1.Text);
            num2 = double.Parse(textBox2.Text);
            result = num1 + num2;
            lblresult.Text = result.ToString();
        }


        //Subtract button
        private void btnminus_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(textBox1.Text);
            num2 = double.Parse(textBox2.Text);
            result = num1 - num2;
            lblresult.Text = result.ToString();
        }


        //Multiply button
        private void btntimes_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(textBox1.Text);
            num2 = double.Parse(textBox2.Text);
            result = num1 * num2;
            lblresult.Text = result.ToString();
        }


        //Divide button
        private void btndivide_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(textBox1.Text);
            num2 = double.Parse(textBox2.Text);
            result = num1 / num2;
            lblresult.Text = result.ToString();
        }


        //Power button
        private void btnpower_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(textBox1.Text);
            num2 = double.Parse(textBox2.Text);
            result = num1 % num2;
            lblresult.Text = result.ToString();
        }


        //Min button
        private void btnmin_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(textBox1.Text);
            num2 = double.Parse(textBox2.Text);
            result = Math.Min(num1, num2);
            lblresult.Text = result.ToString();
        }


        //Max button
        private void btnmax_Click(object sender, EventArgs e)
        {
            num1 = double.Parse(textBox1.Text);
            num2 = double.Parse(textBox2.Text);
            result = Math.Max(num1, num2);
            lblresult.Text = result.ToString();
        }
        //Square root button
        private void btnsqrt_Click(object sender, EventArgs e)
        {
            double num = double.Parse(textBox1.Text);

            if (num >= 0)
            {
                result = Math.Sqrt(num);
                lblresult.Text = result.ToString();
            }
            else
            {
                lblresult.Text = "Invalid Input";
            }
        }
        //Clear button
        private void btnclear_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            lblresult.Text = "";
        }



    }
}
